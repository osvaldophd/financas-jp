<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Escalas;
use Faker\Generator as Faker;

$factory->define(Escalas::class, function (Faker $faker) {
    return [
        //
    ];
});
