<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\VanContactos;
use Faker\Generator as Faker;

$factory->define(VanContactos::class, function (Faker $faker) {
    return [
        //
    ];
});
