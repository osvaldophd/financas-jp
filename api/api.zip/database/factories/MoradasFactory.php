<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Moradas;
use Faker\Generator as Faker;

$factory->define(Moradas::class, function (Faker $faker) {
    return [
        //
    ];
});
