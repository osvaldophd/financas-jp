<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Papeis;
use Faker\Generator as Faker;

$factory->define(Papeis::class, function (Faker $faker) {
    return [
        //
    ];
});
