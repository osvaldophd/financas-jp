<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Mes;
use Faker\Generator as Faker;

$factory->define(Mes::class, function (Faker $faker) {
    return [
        //
    ];
});
