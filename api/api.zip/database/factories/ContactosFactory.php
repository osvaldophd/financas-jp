<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Contactos;
use Faker\Generator as Faker;

$factory->define(Contactos::class, function (Faker $faker) {
    return [
        //
    ];
});
