<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Funcionarios;
use Faker\Generator as Faker;

$factory->define(Funcionarios::class, function (Faker $faker) {
    return [
        //
    ];
});
